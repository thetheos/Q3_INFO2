import src.Array2DBuilderInterface;

public class MyBuilder implements Array2DBuilderInterface {
  public int[][] build_from(String s) {
    //TODO YOUR CODE HERE
  }
  public int sum(int[][] array) {
    //TODO YOUR CODE HERE
  }

  public int[][] transpose(int[][] matrix) {
    //TODO YOUR CODE HERE
  }
  public int[][] product(int[][] matrix1, int[][] matrix2) {
    //TODO YOUR CODE HERE
  }
}
