package public;

public class Disk {

    private int i;

    public Disk(int i){
        this.i=i;
    }

    public int getI() {
        return i;
    }



}
