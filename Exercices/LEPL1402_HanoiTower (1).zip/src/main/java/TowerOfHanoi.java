package public;

import java.util.Stack;

public class TowerOfHanoi{

    /*
     * we want the tower to be moved from a to b.
     * The first value of n is the size of the stack.
     */
    public static void towerOfHanoi(int n, Stack<Disk> a, Stack<Disk> b, Stack<Disk> c) {
        //TODO by student
    }

}
